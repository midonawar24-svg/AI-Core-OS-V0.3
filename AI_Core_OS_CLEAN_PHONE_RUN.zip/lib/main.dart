import 'package:flutter/material.dart';
import 'core/ai/bootstrap/ai_core_bootstrap.dart';
import 'core/ai/config/ai_core_config.dart';
import 'features/chat/presentation/pages/chat_master_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final config = AICoreConfig.defaultConfig();
  final kernel = await AiCoreBootstrap().build(config);
  runApp(AiCoreApp(kernel: kernel));
}

class AiCoreApp extends StatelessWidget {
  final dynamic kernel;
  const AiCoreApp({super.key, required this.kernel});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Core OS v1.3',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const ChatMasterPage(),
    );
  }
}
