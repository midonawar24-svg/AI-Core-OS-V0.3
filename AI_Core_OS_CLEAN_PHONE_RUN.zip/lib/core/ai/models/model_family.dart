enum ModelFamily { qwen, llama, gemma, phi, mistral, custom }
enum ModelType { chat, embedding }

class ModelCapabilities {
  final bool supportsVision;
  final bool supportsTools;
  final bool supportsEmbedding;
  final bool supportsGrammar;
  final bool supportsStreaming;
  final int contextWindow;
  final String tokenizer;
  ModelCapabilities({
    this.supportsVision = false,
    this.supportsTools = false,
    this.supportsEmbedding = false,
    this.supportsGrammar = false,
    this.supportsStreaming = true,
    this.contextWindow = 4096,
    this.tokenizer = "qwen",
  });
  static ModelCapabilities chatDefault() => ModelCapabilities(contextWindow: 8192);
  static ModelCapabilities embeddingDefault() => ModelCapabilities(supportsEmbedding: true, contextWindow: 2048);
}

class ModelSpec {
  final String id;
  final ModelFamily family;
  final ModelType type;
  final String absolutePath;
  final String promptTemplateId;
  final ModelCapabilities capabilities;
  ModelSpec({required this.id, required this.family, required this.type, required this.absolutePath, required this.promptTemplateId, required this.capabilities});
}

class ModelRegistry {
  final Map<String, ModelSpec> _models = {};
  void register(ModelSpec m) => _models[m.id] = m;
  List<ModelSpec> get all => _models.values.toList();
  ModelSpec? getById(String id) => _models[id];
}
