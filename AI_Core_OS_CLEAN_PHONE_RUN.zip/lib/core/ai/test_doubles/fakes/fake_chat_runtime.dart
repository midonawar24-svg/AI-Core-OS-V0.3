import '../../contracts/runtimes.dart';

class FakeChatRuntime implements ChatRuntime {
  String fakeResponse = "وعليكم السلام ورحمة الله وبركاته! أهلاً بك في AI Core OS v0.2.0 - النظام شغال من أوله لآخره ✅ Kernel -> Pipeline -> PromptBuilder -> FakeRuntime";

  @override
  Future<void> load(String path) async {}

  @override
  Future<void> unload() async {}

  @override
  Stream<String> generate(String prompt) async* {
    // Simulate streaming
    final words = fakeResponse.split(' ');
    for (var word in words) {
      await Future.delayed(Duration(milliseconds: 80));
      yield word + ' ';
    }
  }
}

class FailingChatRuntime implements ChatRuntime {
  @override Future<void> load(String path) async => throw Exception("Failed to load");
  @override Future<void> unload() async {}
  @override Stream<String> generate(String prompt) async* { throw Exception("Failed"); }
}
