import '../../contracts/runtimes.dart';

class FakeEmbeddingRuntime implements EmbeddingRuntime {
  @override Future<void> load(String path) async {}
  @override Future<void> unload() async {}
  @override Future<List<double>> embed(String text) async => [1,0,0];
}
