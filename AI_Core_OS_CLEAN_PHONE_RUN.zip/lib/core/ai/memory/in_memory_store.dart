import 'dart:math' as math;
import '../contracts/memory_record.dart';
import '../contracts/vector_store.dart';

class InMemoryMemoryTransaction implements MemoryTransaction {
  final Map<String, MemoryRecord> _target;
  final List<MemoryRecord> _buffer = [];
  InMemoryMemoryTransaction(this._target);
  @override void save(MemoryRecord r) => _buffer.add(r);
  @override void saveAll(List<MemoryRecord> l) => _buffer.addAll(l);
  @override Future<void> commit() async { for(var r in _buffer) _target[r.id]=r; }
  @override Future<void> rollback() async => _buffer.clear();
}

class InMemoryStore implements MemoryStore {
  final Map<String, MemoryRecord> _db = {};
  @override Future<void> save(MemoryRecord r) async => _db[r.id]=r;
  @override Future<MemoryRecord?> getById(String id) async => _db[id];
  @override Future<List<MemoryRecord>> getByIds(List<String> ids) async => ids.map((id)=>_db[id]).whereType<MemoryRecord>().toList();
  @override Future<void> delete(String id) async => _db.remove(id);
  @override Future<MemoryTransaction> beginTransaction() async => InMemoryMemoryTransaction(_db);
}
