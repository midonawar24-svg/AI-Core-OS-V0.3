import 'dart:math' as math;
import '../contracts/vector_store.dart';

class InMemoryVectorTransaction implements VectorTransaction {
  final Map<String, List<double>> _target;
  final List<VectorRecord> _buffer = [];
  InMemoryVectorTransaction(this._target);
  @override void save(VectorRecord r) => _buffer.add(r);
  @override void saveAll(List<VectorRecord> l) => _buffer.addAll(l);
  @override Future<void> commit() async { for(var r in _buffer) _target[r.id]=r.vector; }
  @override Future<void> rollback() async => _buffer.clear();
}

class InMemoryVectorStore implements VectorStore {
  final Map<String, List<double>> _vectors = {};

  double _cosine(List<double> a, List<double> b){
    double dot=0, na=0, nb=0;
    final len = a.length < b.length ? a.length : b.length;
    for(int i=0;i<len;i++){ dot+=a[i]*b[i]; na+=a[i]*a[i]; nb+=b[i]*b[i]; }
    if(na==0||nb==0) return 0;
    return dot / (math.sqrt(na)*math.sqrt(nb));
  }

  @override Future<void> save(VectorRecord r) async => _vectors[r.id]=r.vector;
  @override Future<void> delete(String id) async => _vectors.remove(id);
  @override Future<List<VectorSearchResult>> search(List<double> q, {int topK=5}) async {
    final scored = _vectors.entries.map((e)=> VectorSearchResult(id: e.key, score: _cosine(q, e.value))).toList();
    scored.sort((a,b)=> b.score.compareTo(a.score));
    return scored.take(topK).toList();
  }
  @override Future<VectorTransaction> beginTransaction() async => InMemoryVectorTransaction(_vectors);
}
