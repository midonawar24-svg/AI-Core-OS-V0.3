import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'features/chat/presentation/pages/chat_page_v02.dart';
import 'core/ai/logging/ai_logger.dart';
import 'core/ai/bootstrap/production_bootstrap.dart';
import 'core/ai/config/ai_core_config.dart';
import 'core/ai/kernel/message_processing.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  AILogger.enabled = true;
  AILogger.bootstrap("AI Core OS v0.3.0 - Fllama Adapter - Phase 1: Engine + Adapter separation");
  runApp(ProviderScope(child: AiCoreAppV03()));
}

// Provider now uses ProductionBootstrap with flag
final kernelProviderV03 = Provider((ref) {
  // Change to realConfig() when model file exists
  final config = AICoreConfig.fakeConfig(); // Start with fake, swap to realConfig() for real test
  return ProductionBootstrap.build(config: config);
});

final messageServiceProviderV03 = Provider((ref) {
  final kernel = ref.read(kernelProviderV03);
  return MessageProcessingService(kernel);
});

class AiCoreAppV03 extends StatelessWidget {
  const AiCoreAppV03({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Core OS v0.3.0 - Fllama Adapter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: ChatPageV03(),
    );
  }
}

class ChatPageV03 extends ConsumerStatefulWidget {
  const ChatPageV03({super.key});
  @override ConsumerState<ChatPageV03> createState() => _ChatPageV03State();
}

class _ChatPageV03State extends ConsumerState<ChatPageV03> {
  final TextEditingController _controller = TextEditingController();
  final List<dynamic> _messages = [];
  bool _isStreaming = false;
  String _status = "Ready - FllamaChatRuntime(FllamaEngine) - State: uninitialized";
  final List<String> _logs = [];

  Future<void> _send() async {
    final query = _controller.text.trim();
    if (query.isEmpty || _isStreaming) return;

    setState(() {
      _messages.add({"role": "user", "text": query});
      _isStreaming = true;
      _status = "Generating...";
      _logs.clear();
    });
    _controller.clear();

    final service = ref.read(messageServiceProviderV03);
    final kernel = ref.read(kernelProviderV03);

    // Check state machine
    final runtime = kernel.runtimeController.chatRuntime;
    if (runtime is FllamaChatRuntime) {
      setState(() => _logs.add("[State] Before: \${runtime.state}"));
    }

    final response = service.processMessage(MessageRequest(query: query));
    final ctx = await response.contextFuture;

    setState(() {
      _logs.add("[Pipeline] \${ctx.entries.length} entries");
      _messages.add({"role": "assistant", "text": ""});
    });

    try {
      final buffer = StringBuffer();
      await for (final token in response.stream) {
        buffer.write(token);
        setState(() => _messages.last["text"] = buffer.toString());
      }
      setState(() {
        _status = "Ready - \${ctx.entries.length} entries - State: \${runtime is FllamaChatRuntime ? runtime.state : 'unknown'}";
        _isStreaming = false;
        if (runtime is FllamaChatRuntime) _logs.add("[State] After: \${runtime.state} - Idle");
      });
    } catch (e) {
      setState(() {
        _logs.add("[Error] \$e");
        _status = "Error: \$e";
        _isStreaming = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("v0.3.0 - Fllama Adapter (Engine+Adapter)"),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(100),
          child: Padding(
            padding: EdgeInsets.all(8),
            child: Column(
              children: [
                Text(_status, style: TextStyle(fontSize: 11, color: Colors.greenAccent)),
                SizedBox(height: 4),
                Container(
                  height: 50,
                  color: Colors.black87,
                  child: ListView.builder(
                    itemCount: _logs.length,
                    itemBuilder: (c,i) => Text(_logs[i], style: TextStyle(fontSize: 9, fontFamily: 'monospace', color: Colors.grey)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            color: Colors.grey[900],
            padding: EdgeInsets.all(6),
            child: Text("UI -> Kernel -> RuntimeController -> ChatRuntime(Contract) -> FllamaChatRuntime(Adapter) -> FllamaEngine(Wrapper) -> fllama package", style: TextStyle(fontSize: 8, color: Colors.grey), textAlign: TextAlign.center),
          ),
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (c,i) {
                final m = _messages[i];
                final isUser = m["role"] == "user";
                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 4),
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(color: isUser ? Colors.blue[800] : Colors.grey[850], borderRadius: BorderRadius.circular(12)),
                    child: Text(m["text"], style: TextStyle(color: Colors.white)),
                  ),
                );
              },
            ),
          ),
          if (_isStreaming) LinearProgressIndicator(),
          Padding(
            padding: EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _controller, onSubmitted: (_) => _send(), decoration: InputDecoration(hintText: "جرب: السلام عليكم - نفس UI بدون تغيير", border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))))),
                SizedBox(width: 8),
                IconButton.filled(onPressed: _send, icon: Icon(Icons.send)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
