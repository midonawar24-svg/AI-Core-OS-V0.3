import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'features/chat/presentation/pages/chat_page_v02.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ProviderScope(child: AiCoreAppV02()));
}

class AiCoreAppV02 extends StatelessWidget {
  const AiCoreAppV02({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Core OS v0.2.0',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: ChatPageV02(),
    );
  }
}
